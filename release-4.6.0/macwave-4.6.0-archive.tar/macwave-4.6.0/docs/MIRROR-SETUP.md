# 搭建 MacWave 镜像站（宝塔 + 香港轻量服务器）

面向国内用户。**为什么要做镜像**：从大陆访问 `github.com` 极不稳定 —— 实测连测三次，两次在 20 秒内连 TCP 都没建立；同一时刻国内镜像站 37~78 ms 就返回了。MacWave 的产物又偏大（pandoc 40 MB、ollama 172.9 MB），这种链路基本下不完。

## 整体链路

```
上游（jqlang/jq、conda-forge…）
   │  ① GitHub Actions 抓取（Runner 就在 GitHub 机房内，不受大陆出口影响）
   ▼
MacWaveOrg/Bottle · Releases      每个包一个 tag，资产名 <包名>@<版本>.<架构><扩展名>
   │  ② 香港服务器同步（国际链路，正常）
   ▼
mirror.repohub.top/MacWave       宝塔 + nginx，纯静态文件树
   │  ③ 大陆用户下载（20~50 ms）
   ▼
用户机器
```

三段的职责不能混：**抓上游只在 Actions 里做**，香港只负责「复制 + 服务」，用户的机器只读镜像。

## 为什么根目录是 `MacWave/` 而不是整个域名

域名顶层留给别的产品。LinuxWave 很可能也要镜像站，那时它用 `mirror.repohub.top/LinuxWave`，
两套互不干扰：

```
/www/wwwroot/mirror.repohub.top/
├── MacWave/          ← 本项目
│   ├── bottle/
│   ├── deps/
│   └── selfupdate/
└── LinuxWave/        ← 预留，现在不用创建
```

`LinuxWave/` 只是**预留位置**，知道有这回事即可，本文任何一步都不需要建它。将来 LinuxWave
要镜像时，它用 `mirror.repohub.top/LinuxWave`，与这里互不干扰。

所以本文所有路径都带 `MacWave/` 这一层，环境变量的值也要带上。
**注意大小写**：目录名是 `MacWave`，首字母大写，与仓库名一致。Linux 上无所谓，但保持一致省得以后混。

## 前置条件

| 项 | 说明 |
| --- | --- |
| 服务器 | 香港轻量应用服务器，1 核 1G 起，**30 Mbps 峰值带宽**，Ubuntu 22.04 / Debian 12 |
| 域名 | 一条 A 记录指向服务器公网 IP |
| 备案 | **不需要**。备案只针对中国大陆境内的服务器 |
| SSL | 宝塔里用 Let's Encrypt 免费申请 |

**不要买大陆节点**：那需要 ICP 备案，而备案要求域名在工信部批复的注册服务机构注册 —— 在 NameSilo 这类海外注册商注册的域名通常过不了。

**带宽是重点**。轻量服务器标的都是峰值带宽：

| 带宽 | 实际速度 | 下 ollama（172.9 MB） |
| --- | --- | --- |
| 5 Mbps | ~0.6 MB/s | 约 5 分钟 |
| 30 Mbps | ~3.7 MB/s | 约 47 秒 |

另外留意月流量包（通常 1 TB）。那是给**用户下载**算的，超出会限速或另计费。

## 第一步：服务器与宝塔

购买后记下**公网 IP** 和 root 密码，SSH 登录，按宝塔官网给出的对应系统命令安装面板。

装完先做三件安全事：

1. 面板设置里改掉默认端口 8888（该端口被全网扫描）；
2. 开启「面板 SSL」；
3. 软件商店只装 **Nginx**，**不装 PHP、不建数据库** —— 镜像站没有任何后端逻辑，少一个攻击面。

## 第二步：DNS

加一条 A 记录：

```
mirror.repohub.top    A    <服务器公网 IP>
```

生效判断：`ping mirror.repohub.top` 返回的正是那个 IP。**必须在下一步之前生效**，否则 SSL 申请会失败。

## 第三步：建站

宝塔 → 网站 → 添加站点：

| 项 | 值 |
| --- | --- |
| 域名 | `mirror.repohub.top` |
| 根目录 | `/www/wwwroot/mirror.repohub.top`（站点根；MacWave 的数据在它下面的 `MacWave/`） |
| PHP 版本 | **纯静态** |
| 数据库 | 不创建 |

## 第四步：放入文件

最终必须是这个结构……

> **`ROOT` 必须等于 nginx 里 `alias` 指的那棵树。** 本文下面所有路径都以
> `/www/wwwroot/mirror.repohub.top` 为例，但**服务器上未必是这个目录** —— 实测
> `mirror.repohub.top` 的 nginx 把它指到了 `/srv/mirror/`：
>
> ```nginx
> location ^~ /MacWave/infosource/ {
>     alias /srv/mirror/MacWave/infosource/;
> }
> ```
>
> 同步脚本默认往 `/www/wwwroot/mirror.repohub.top/MacWave` 写。**两棵树对不上时，
> 同步照样「成功」，日志全绿，而客户端读的是另一棵没人更新的树** —— 症状是某个
> 新发布的包在客户端「不在索引里」，其余包一切正常，排查时最容易被误判成上游数据
> 没同步。两行命令先确认现场：
>
> ```bash
> nginx -T 2>/dev/null | grep -A2 'location .*MacWave' | grep -E 'location|alias'
> curl -sI https://mirror.repohub.top/MacWave/infosource/HEAD/README.md | grep -i content-length
> ls -l "$ROOT/MacWave/infosource/HEAD/README.md"    # 大小要与上一条一致
> ```
>
> 自查一律走 `https://` 或带 `Host` 头：`http://127.0.0.1/…` 在开了「强制 HTTPS」的
> 站点上只返回 301，拿到的不是内容（见第七步）。
>
> 对不上就二选一：把 cron 里的 `ROOT` 改成 `alias` 那个目录，或者让 `alias` 指向
> `ROOT`（例如把 `/srv/mirror` 换成指向同一棵树的符号链接，注意先迁移数据）。
>
> 还有一种常见的历史包袱：**站点被一个个 `location` 手工拼出来**，于是同一台机器上
> 同时存在 `MacWave/MacWave/`（放着 `bottle`、`deps`）、`MacWave/infosource/`、
> `MacWave/core/` 等不同的树。这种情况下 `DEST=$ROOT/MacWave` 里没有 `bottle/`，
> 清单重建会在最后一步失败。两条路：
>
> - 用 `MIRROR_ROOT` 指到真正有 `bottle/` 的那一层（不必搬数据）：
>   `ROOT=/srv/mirror MIRROR_ROOT=/srv/mirror/MacWave/MacWave ./mirror-sync.sh --no-payloads`
>   （`ls` 一下确认哪一层有 `bottle/`：`ls -d /srv/mirror/MacWave/*/bottle`）
> - 或者一次搬干净，让站点只剩一层：
>
>   ```
>   /srv/mirror/MacWave/{bottle,deps,infosource/HEAD,core,selfupdate,python}
>   ```
>
>   然后把 nginx 收成一条 `location ^~ /MacWave/ { alias /srv/mirror/MacWave/; }`。
>   这条最省事：客户端的六类地址全都落在这一个前缀下面。

结构：

```
/www/wwwroot/mirror.repohub.top/
└── MacWave/
    ├── infosource/
    │   └── HEAD/                     ← ref 那一层，客户端默认地址里就有
    │       ├── README.md
    │       ├── versions              ← 包名清单（build_versions_index.py 生成）
    │       └── pkg/pkginfo_arm64/
    │           ├── versions          ← 版本号清单（同上）
    │           └── jq/
    │               └── versions
    ├── selfupdate/
    │   └── macwavedata/latest.toml   ← 没有 ref 层
    ├── python/
    │   └── pythondata/…
    ├── core/
    │   └── 4.4/…                     ← 分支就是那一层
    ├── bottle/
    │   └── jq/
    │       └── jq@1.7.1.arm64
    └── deps/
        └── libidn2/
            └── libidn2@2.3.7.arm64.tar.gz
```

**只有 `infosource/` 在地址里多一层 ref，其余都没有。** 这不是设计不一致而是跟着上游
地址走的：`infosource` 的默认地址是 `…/MacWaveOrg/infosource/HEAD`（`HEAD` 是默认分支的
别名），`selfupdate` / `python` 的默认地址以 `/main` 结尾、客户端拼路径时不再接 ref，
`core` 拼的是分支名。

磁盘上那层 `HEAD` 有两种做法，**选一种并保证客户端拿到的就是同步脚本写的那棵树**：

| 做法 | 做法细节 |
| --- | --- |
| A. 铺进真实目录（**`mirror-sync.sh` 从 4.4 起默认这么做**） | `rsync` 目标就是 `$DEST/infosource/HEAD/`，站点只写一条 `alias /…/MacWave/infosource/` 即可 |
| B. nginx 别名 / 符号链接 | 数据放 `$DEST/infosource/`，用 `location ~ ^/MacWave/infosource/HEAD/(.*)$ { alias …/MacWave/infosource/$1; }` 顶上（早先的服务器是这么做的） |

两种都能用，**但别名指错地方的后果很隐蔽**：客户端照样 200、`wave install` 却发现
某个新包「不在索引里」，因为 `/HEAD` 指向的是一份没人再更新的旧拷贝。判断办法是比
`README.md` 的 `content-length` / `Last-Modified` 与磁盘上的那份：

```bash
curl -sI "$MACWAVE_API_DOMAIN/README.md" | grep -iE 'content-length|last-modified'
ls -l /www/wwwroot/mirror.repohub.top/MacWave/infosource/README.md
# 两行不一致 = /HEAD 没有指向同步出来的那棵树
```

而少了 `HEAD` 那一层（或别名指错），**所有**包的「列出版本」都会 404 —— 症状是
`wave install` 说「读不到版本清单」，`wave search`、`wave latest` 一起失灵。

**这一步最容易出错**：很多压缩工具会在外面多包一层目录，解出来变成 `.../mirror/bottle/...`，于是 URL 里凭空多出 `/mirror`，全部 404。

检查方法：

```bash
ls /www/wwwroot/mirror.repohub.top/MacWave/
# 必须直接看到 bottle 和 deps，不能再多一层 MacWave/MacWave/
```

文件怎么来，两种方式：

**方式 A（推荐，从 GitHub Releases 拉）**

在服务器上执行，它按索引里的清单逐个下载并校验 sha256：

```bash
git clone --depth 1 https://github.com/MacWaveOrg/MacWave /tmp/macwave-src
git clone --depth 1 https://github.com/MacWaveOrg/infosource /tmp/infosource

python3 /tmp/macwave-src/scripts/sync_payloads.py \
  --infosource /tmp/infosource \
  --out /www/wwwroot/mirror.repohub.top/MacWave \
  --source payload \
  --jobs 6
```

`--source payload` 表示「从我们自己的 Release 取」而不是打扰上游。首次全量约 1.5 GB，之后重复运行只补新增（已存在且校验通过的文件会跳过）。

**方式 B（少量文件）**：从 Release 页面手动下载附件，用宝塔「文件」上传。

## 第五步：nginx 缓存头

文件永不覆盖（要改就发新的版本后缀，例如 `1.7.1-1`），所以可以放心让客户端长期缓存。

宝塔 → 网站 → 设置 → 配置文件，在 `server { }` 内加入：

```nginx
# 文件名里带 @（URL 中是 %40），nginx 会自动解码，这里只加缓存头
location ~ @ {
    add_header Cache-Control "public, max-age=31536000, immutable";
}

location ~* \.(tar\.gz|tgz|zip|tar\.bz2|tar\.xz|conda)$ {
    add_header Cache-Control "public, max-age=31536000, immutable";
}
```

改完在宝塔里重载 nginx。

> 缓存头解决的是「重复下载不再回源」。**限速、防爆破、以及校园网 NAT 下怎么限才
> 不误伤自己人**，见后面的[「别被打穿」](#别被打穿限速防爆破与校园网)一节。

## 第六步：SSL

宝塔 → 网站 → 设置 → SSL → Let's Encrypt，申请后打开「强制 HTTPS」。

## 第七步：验证

浏览器直接打开（注意 `@` 在 URL 里写作 `%40`）：

```
https://mirror.repohub.top/MacWave/bottle/jq/jq%401.7.1.arm64
```

能下载就说明镜像站可用。再量一下速度：

```bash
curl -o /dev/null -w '速度 %{speed_download} B/s\n' \
  https://mirror.repohub.top/MacWave/bottle/jq/jq%401.7.1.arm64
```

**在服务器上自查时不要用 `http://127.0.0.1/…`。** 站点开了「强制 HTTPS」，这个地址
返回的是 **301**，不是内容；`curl` 不加 `-L` 时拿到的 301 页面正文只有 7 行，
`wc -l` 数出来就是 7 —— 看着像「清单只剩 7 个包」，其实一个包都没读到。三种正确写法：

```bash
# A. 带 Host 头，让 nginx 用对 server 块（http 会 301，所以用 https）
curl -sk --resolve mirror.repohub.top:443:127.0.0.1 \
     https://mirror.repohub.top/MacWave/infosource/HEAD/pkg/pkginfo_arm64/versions | wc -l

# B. 直接走域名（最省事）
curl -s https://mirror.repohub.top/MacWave/infosource/HEAD/pkg/pkginfo_arm64/versions | wc -l

# C. 只看状态码时记得跟随跳转
curl -sL -o /dev/null -w '%{http_code}\n' \
     https://mirror.repohub.top/MacWave/infosource/HEAD/pkg/pkginfo_arm64/columbula/versions
```

另外 `nginx -T` 里还有一个 `server_name 127.0.0.1` 的监控块（只放 `nginx_status`），
它没有 MacWave 那套 `alias` —— 用 `127.0.0.1` 自查时容易被它或 301 误导。

同时确认校验值没被中间环节改坏：

```bash
curl -fsSL https://mirror.repohub.top/MacWave/bottle/jq/jq%401.7.1.arm64 | shasum -a 256
# 与 infosource 里 _jq@1.7.1 的 sha256 应当逐字相同
```

## 第八步：首次安装就走镜像

前面几节假设 MacWave 已经装好了。但首次安装时用户还没有 `~/.zshrc` 里的那几行，所以要把变量
写在**同一条命令的前面**：

```bash
MACWAVE_CORE_DOMAIN=https://mirror.repohub.top/MacWave/core \
MACWAVE_SELFUPDATE_DOMAIN=https://mirror.repohub.top/MacWave/selfupdate \
MACWAVE_PYTHON_DOMAIN=https://mirror.repohub.top/MacWave/python \
/bin/bash -c "$(curl -fsSL https://mirror.repohub.top/MacWave/core/lib/install.sh)"
```

**注意 `install.sh` 那一行本身也要能取到。** 如果镜像开了 HTTP 基本认证（401），
上面这条命令会停在 `curl` 那一步 —— 而 `MACWAVE_*_DOMAIN` 只管 MacWave 自己发的
请求，管不到外层的 `curl`。三条出路，按推荐顺序：

1. **给这一条路径开匿名只读**（推荐）。`install.sh` 是 Apache-2.0 的公开代码，挡它没有
   意义；二进制与索引继续要认证即可：

   ```nginx
   location = /MacWave/core/lib/install.sh {
       auth_basic off;
       alias /www/wwwroot/mirror.repohub.top/MacWave/core/lib/install.sh;
   }
   ```

   分支目录同理，若客户端按 `<CORE>/<分支>/lib/install.sh` 取：
   `location ~ ^/MacWave/core/[^/]+/lib/install\.sh$ { auth_basic off; }`

2. **把凭据写进 URL**（只适合自己人，且要当成口令保管）：

   ```bash
   /bin/bash -c "$(curl -fsSL https://USER:TOKEN@mirror.repohub.top/MacWave/core/lib/install.sh)"
   ```

3. **先把脚本存到本机再跑**（校园网 / 内网最省事，也便于逐字核对）：

   ```bash
   curl -fsSL -o /tmp/mw-install.sh https://mirror.repohub.top/MacWave/core/lib/install.sh
   less /tmp/mw-install.sh          # 看一眼再执行
   MACWAVE_CORE_DOMAIN=… /bin/bash /tmp/mw-install.sh
   ```

这里出现了另外两个变量，含义与前面不同：

| 变量 | 取什么 | 镜像要承载 |
| --- | --- | --- |
| `MACWAVE_API_DOMAIN` | 软件包索引与「列出版本」清单 | `<根>/MacWave/infosource/<ref>/…` |
| `MACWAVE_CORE_DOMAIN` | MacWave 自身的代码（`lib/`、`pkg/`、`surfboard/`） | `<根>/MacWave/core/<分支>/…` |
| `MACWAVE_PYTHON_DOMAIN` | 自带 CPython（独立仓库） | `<根>/MacWave/python/pythondata/…` |

`infosource/` 底下那层 ref **必须写在变量值里**（MacWave 用 `HEAD`）：

```
export MACWAVE_API_DOMAIN=https://<根>/MacWave/infosource/HEAD   ← 正确
export MACWAVE_API_DOMAIN=https://<根>/MacWave/infosource        ← 错误，全部 404
```

与下面 `core/` 的分支层是同一类坑，但后果更广：少了 ref 不是某个包出问题，
而是**所有**包都装不上 —— `wave install` 停在「读不到版本清单」，`wave search`
与 `wave latest` 同样失败。`bottle/`、`deps/` 不是 git 仓库，没有这一层。

`core/` 的形状有个坑：客户端按 **`<CORE_DOMAIN>/<分支>/<路径>`** 取文件
（`BASE_URL="$CORE_URL/$BRANCH"`），所以分支名必须是一层真实目录：

```
MacWave/core/4.0/lib/wave.py        ← 正确
MacWave/core/lib/wave.py            ← 错误，缺了分支这一层，会 404
```

在镜像服务器上按分支铺：

```bash
for branch in 4.0 3.2; do
  git clone --depth 1 --branch "$branch" https://github.com/MacWaveOrg/MacWave \
    "/www/wwwroot/mirror.repohub.top/MacWave/core/$branch"
  rm -rf "/www/wwwroot/mirror.repohub.top/MacWave/core/$branch/.git"
done
```

⚠️ 但这里有个现实问题：**MacWave 自身的代码更新频率高**，而 `core/` 是 git 克隆的副本，
不会自动跟着走。镜像它意味着你要定期重新拉取，否则用户拿到的是旧代码。

**所以我的建议是：`core` 保持官方地址，不去镜像它。** 它只有几百 KB、只在下
载 MacWave 本身时请求一次，不是慢的主要来源——真正大的是 `bottle` 的几十到几百 MB。
绝大多数用户只需要镜像 `bottle` 和 `deps`。

## 第九步：让已装好的 MacWave 用它

已经装好、只是下载慢的情况。三行写进 `~/.zshrc`：

```bash
export MACWAVE_BOTTLE_DOMAIN=https://mirror.repohub.top/MacWave/bottle
export MACWAVE_DEPS_DOMAIN=https://mirror.repohub.top/MacWave/deps
export MACWAVE_SELFUPDATE_DOMAIN=https://mirror.repohub.top/MacWave/selfupdate
```

写进 `~/.zshrc` 长期生效，然后 `source ~/.zshrc`。

前两个变量的值里带 `/bottle` 与 `/deps`，因为镜像根目录下就是这两棵子树。想再镜像自更新数据的话，把 `MacWaveOrg/Selfupdate` 的内容放到 `.../selfupdate/`，第三个变量才需要设。

验证真的走了镜像：

```bash
curl -sI "$MACWAVE_BOTTLE_DOMAIN/jq/jq%401.8.2.arm64" | head -1
# 期望 HTTP/2 200
wave install jq
```

## 第十步：切回官方地址

**用户迟早会问这个。** 两种方式，效果不同：

| 方式 | 命令 | 何时失效 |
| --- | --- | --- |
| **改配置（推荐）** | 从 `~/.zshrc` 删掉那几行 `export`，再 `source ~/.zshrc` | 永久 |
| **临时关掉** | `unset MACWAVE_BOTTLE_DOMAIN MACWAVE_DEPS_DOMAIN MACWAVE_SELFUPDATE_DOMAIN` | 只影响当前终端，新开窗口又回来 |

确认已切回：

```bash
echo "${MACWAVE_BOTTLE_DOMAIN:-(未设置 → 用官方地址)}"
```

**一个变量都不设 = 与 3.x 完全相同的地址。** 这就是默认值仍指向官方源的原因：不设就是原样。

**可以只镜像一部分。** 三个变量互相独立，没设的那个继续用官方地址。例如只镜像二进制、自更新仍走官方：

```bash
export MACWAVE_BOTTLE_DOMAIN=https://mirror.repohub.top/MacWave/bottle
export MACWAVE_DEPS_DOMAIN=https://mirror.repohub.top/MacWave/deps
# 不设 MACWAVE_SELFUPDATE_DOMAIN
```

## 哪些操作受这些变量影响

| 操作 | 受镜像变量影响 | 说明 |
| --- | --- | --- |
| `wave install <包>` | ✅ | 二进制走 `BOTTLE` / `DEPS` |
| `wave upgrade <包>` | ✅ | 同上 |
| `wave selfupdate` | ✅ | 版本数据与文件清单走 `SELFUPDATE` |
| `wave search` / `wave info` | ⚠️ 部分 | 索引走 `API`；但「列版本」目前仍走 `api.github.com` |
| `curl … install.sh` 首次安装 | ❌ | 除非按第十步把变量写在命令前 |
| `git clone` 源码 | ❌ | git 不认这些变量 |

最后一行最容易误会：**`MACWAVE_*_DOMAIN` 只管 MacWave 自己发的请求**，管不到 `git` 和 `curl` 的下载。

## 可选的第三块：自更新数据与解释器

这两块不是二进制，体积很小（解释器归档除外，每架构约 26 MB），直接从仓库复制即可：

```bash
git clone --depth 1 https://github.com/MacWaveOrg/Selfupdate \
  /www/wwwroot/mirror.repohub.top/MacWave/selfupdate
rm -rf /www/wwwroot/mirror.repohub.top/MacWave/selfupdate/.git

git clone --depth 1 https://github.com/MacWaveOrg/Python \
  /www/wwwroot/mirror.repohub.top/MacWave/python
rm -rf /www/wwwroot/mirror.repohub.top/MacWave/python/.git
```

目录形状与每类数据的确切规则见 [DATA-LAYER.md](DATA-LAYER.md)。

## 让镜像自己跟上上游（自动同步）

手动 rsync 的问题是**会忘**：发了新版、镜像还是旧的，而客户端拿到 404 只会说「下载失败」，
没人会来告诉你。所以同步也交给服务器自己。

`MacWave/` 下五类东西来源不同，脚本按来源分别处理：

| 目标 | 来源 | 处理 |
| --- | --- | --- |
| `infosource/HEAD/` | `MacWaveOrg/infosource` 的 `main` | 浅克隆 + `rsync --delete`，铺进一层 `HEAD/`（客户端地址里就有这层；见第四步） |
| `selfupdate/` | `MacWaveOrg/Selfupdate` 的 `main` | 同上 |
| `python/` | `MacWaveOrg/Python` 的 `main` | 同上 |
| `core/<分支>/` | `MacWaveOrg/MacWave` 的对应分支 | 同上；分支表 = `configdata` 的当前发布线 + `KEEP_BRANCHES` |
| `python/pythondata/<版本>/*.tar.gz` | `python_url.toml` 里记的**上游**地址 | 自己下载并校验 sha256；仓库里没有二进制 |
| `bottle/` `deps/` | 我们自己的 Bottle / Deps **Release** | `sync_payloads.py --source payload`，只增不删；坏记录按 `scripts/known-bad-records.txt` 跳过 |

最后再跑一次 `build_versions_index.py` 重建 `versions` 清单 —— 客户端的「列出版本」
靠它，漏了会表现为「没有版本可装」。

三个文件在 [scripts/mirror-sync/](../scripts/mirror-sync/)：

| 文件 | 作用 |
| --- | --- |
| `mirror-sync.sh` | 同步本体 |
| `sync-run.sh` | cron 包装：记 `history.log`，失败建 `ALERT`、通过删 `ALERT` |
| `sync-install.sh` | 落地 cron 行并试跑一次 |

```bash
# Mac 上
# known-bad-records.txt 也要一起传：脚本优先读它旁边那份
rsync -a -e "ssh -o ControlPath=$HOME/.ssh/cm-lw" \
  scripts/mirror-sync/ scripts/known-bad-records.txt \
  root@<服务器>:/root/mirror-sync/

# 服务器上
/bin/bash /root/mirror-sync/sync-install.sh
```

cron 定在 **03:23**，排在巡检（04:17）之前 —— 先同步再体检，体检看到的就是同步后的状态。

### 发版之后主动触发一次

cron 一天只跑一次（03:23），所以**发完版要自己踢一脚**，别等第二天：

```bash
# Mac 上一条命令：复用已有的 ssh 连接（ControlPath），跑完把结论打出来
ssh -o ControlPath=$HOME/.ssh/cm-lw root@<服务器> \
  '/bin/bash /root/mirror-sync/sync-run.sh; tail -3 /root/mirror-sync/history.log'

# 先看一眼会动哪些树、不写文件
ssh -o ControlPath=$HOME/.ssh/cm-lw root@<服务器> \
  '/bin/bash /root/mirror-sync/mirror-sync.sh --dry-run'
```

`sync-run.sh` 是 cron 用的那个包装：跑 `mirror-sync.sh` → 往 `history.log` 记一行 →
失败建 `ALERT`、成功删 `ALERT`。直接调 `mirror-sync.sh` 也可以，只是不留 `history.log`。

**同步完怎么自检**（镜像开了 `auth_basic`，裸 `curl` 一律 401，别拿它当失败 ——
2026-11-19 实测 `mirror.repohub.top` 上六条客户端路径匿名全是 401）

最省事的是在服务器上直接看文件 —— 不经过认证层：

```bash
ssh -o ControlPath=$HOME/.ssh/cm-lw root@mirror.repohub.top \
  'M=/www/wwwroot/mirror.repohub.top/MacWave
   grep ^version $M/selfupdate/macwavedata/latest.toml
   grep ^version $M/selfupdate/rcdata/latest.toml
   grep ^build_number $M/selfupdate/macwavedata/latest.toml
   ls -l $M/core/4.4/lib/selfupdate.sh $M/selfupdate/macwavedata/latest.toml.sig'
```

要验「外面能不能取到」，就带凭据（`curl -u 用户名` 会**交互式问口令**，别把口令写进命令行，
那会留在 shell 历史里）：

```bash
for u in selfupdate/macwavedata/latest.toml selfupdate/rcdata/latest.toml \
         core/4.4/lib/selfupdate.sh; do
  printf '%-46s ' "$u"
  curl -u '<账号>' -s -o /dev/null -w '%{http_code}\n' "https://mirror.repohub.top/MacWave/$u"
done
```

**更要紧的是验客户端那条路**：客户端（`install.sh` / `wave selfupdate`）不带凭据，
所以它要读的那几个地址必须能匿名 200 —— 靠 nginx 的 `auth_basic off` 例外，或者
把凭据写进 `MACWAVE_*_DOMAIN`（`https://user:pass@host`，客户端支持，日志里会打码）。

```bash
for u in selfupdate/macwavedata/latest.toml selfupdate/macwavedata/latest.toml.sig \
         selfupdate/macwavedata/4.4.0/update_commands.sh core/4.4/lib/install.sh; do
  printf '%-52s ' "$u"
  curl -s -o /dev/null -w '%{http_code}\n' "https://mirror.repohub.top/MacWave/$u"   # 不加 -u
done
```

四条都得是 `200`。出现 `401` 说明那个路径没有例外规则，客户端走镜像会失败 ——
例外清单见本文件前面「注意 `install.sh` 那一行本身也要能取到」那一节。

### 三种跑法

```bash
/bin/bash /root/mirror-sync/mirror-sync.sh --dry-run       # 只看会动哪些树，不写文件
/bin/bash /root/mirror-sync/mirror-sync.sh --no-payloads   # 只同步 git 树与清单（快）
/bin/bash /root/mirror-sync/mirror-sync.sh                 # 全量，含产物
```

退出码 0 表示全部成功，1 表示有任何一步失败。`cron` 里默认带 `--no-payloads`：
产物体积大、变动少，先确认 git 树这条路稳了，再决定要不要把产物也交给它。

### 几条「故意做坏」的记录

索引里有 4 条记录是**负向测试夹具**，本来就取不到：`test_001` 上游 404、
`test_no_sha256` 缺校验值、`test_wrong_sha256` 校验值故意不符、`ldid` 上游不可用。

不跳过它们，每次同步都会报同样的失败 —— 而真正的问题会淹没在同一批报错里。名单放在
`scripts/known-bad-records.txt`，**CI 与同步脚本共用同一份**，免得两边走散。
脚本优先读它旁边那份（部署时一起传上去），再读工具克隆里的 —— 后者要等改动进了 `main`
才有，而镜像不该等一次合并才能正确工作。

### 为什么解释器压缩包要单独一步

`MacWaveOrg/Python` 里只有 toml，没有那两个约 26 MB 的压缩包 —— 二进制不进 git。
但客户端默认不是回上游取，而是取镜像上那份：

```python
def python_archive_url(version, filename):
    return f"{python_data_domain()}/pythondata/{version}/{filename}"
```

所以镜像必须自己把它们放在 `pythondata/<版本>/` 下。同步脚本在 git 树同步完之后
读 `latest.toml` 与 `python_url.toml`，两个架构都补（与这台服务器是什么架构无关，
镜像要同时服务两种 Mac），逐字节校验，**验不过就丢弃**：宁可少一个文件，也不要
在镜像里留一份校验不符的。

### 必须记住的五点

| 点 | 为什么 |
| --- | --- |
| **`versions` 不能跟着 `--delete` 消失** | 它是本地生成的，上游没有。rsync 里 `--exclude versions` 保它，第 5 步再重建 |
| **`infosource/.git` 不该留在站点里** | 索引是 `git clone` 来的，`.git` 会一并被服务；nginx 的 `location ~ /\.` 挡住它，但没必要留。同步末尾直接删 |
| **同步失败时不能清理旧分支目录** | 发布线刚切到 `4.5`、而 `4.5` 分支还没建时，清理会把仍在服务的 `4.1` 删掉 —— 一次上游打嗝变成镜像全站不可用。脚本里只要有一个 core 分支没同步成功就跳过清理 |
| **`pythondata/*.tar.gz` 必须排除在 `--delete` 之外** | 它们在仓库里不存在，rsync 的 `--delete` 会当成「上游删了」而清掉。实测确认：不排除时两个压缩包会被删，镜像从此装不了自带解释器 |
| **`bottle/deps` 只增不删** | 上游删掉一个旧包时，镜像里已有的文件不该跟着消失：客户端的索引缓存可能还指着它 |
| **代码树与产物树可以在两个根下** | 历史机器上出现过 `/www/…/MacWave/bottle`（产物）+ `/srv/mirror/MacWave/infosource`（代码树）。这时 `ROOT` 填代码树那个根，`MIRROR_ROOT` 指向有 `bottle/` 的那一层 |

另外，产物那一步走的是 `--source payload`，即从**我们自己的 Release** 取，不打扰上游。
它依赖 `domains.py` 的内置默认值，所以脚本开头会显式 `unset MACWAVE_*_DOMAIN` ——
否则这台机器上残留的镜像变量会把路径指到别处，变成「从镜像同步镜像」。

> **LinuxWave 暂未纳入**：它的客户端还没定稿，且缺少与之配套的 `sync_payloads`。
> 等那边统一处理时，`mirror-sync.sh` 的结构可以直接照搬，只有 `ORG` 与产物来源要换。

## 旧布局怎么清（会用到一次）

镜像跑过一阵之后，站点上常会留下**没人再读的副本**：早先手工铺的目录、脚本改过落点
之后的旧位置、按仓库名建的大写目录。它们的害处不是占空间，而是**排查时对着错误的
那份看**（这次的 columbula 就是对着停在两天前的旧拷贝查了半天）。

清理原则：**先移到隔离目录，确认一周没问题再删**，不要 `rm -rf` 上线。

> **按名字猜哪棵树在服务，一定会错。** 实测遇到过这样的站点：同一个 `/MacWave/`
> 前缀下，`location ^~ /MacWave/infosource/` 指向 `/srv/mirror/…`，而
> `core`、`selfupdate`、`python`、`bottle`、`deps` 根本没有自己的 location ——
> 它们落到通用的 `location /`，由它的 `root` 从 `/www/wwwroot/…` 取。
> 于是「把 `/www` 下那几份没人读的代码树挪走」直接让 `wave install` 全线 404，
> 而 `infosource` 照旧 200，看着像只坏了一半。
>
> 所以动手前**逐条**核对，两件事都要做：
>
> ```bash
> # a) 每个 location 的 alias / root 是什么
> nginx -T 2>/dev/null | grep -A3 'location' | grep -E 'location|alias|root' \
>   | grep -iE 'macwave|core|bottle|deps|python|selfupdate'
>
> # b) 有没有人真的在读某个前缀（读访问日志，不靠感觉）
> grep -cE 'MacWave/(Selfupdate|Python|MacWave)/' /www/wwwlogs/*.log 2>/dev/null
> ```
>
> 只看 (a) 还不够：`core`/`deps`/`bottle` 这类**没有自己的 location** 的前缀，
> 靠 `(b)` 才能确认访问量。

```bash
# 0) 先给现状留个底
STAMP=$(date +%F)
ls -la /srv/mirror/MacWave > /root/macwave-mirror-$STAMP.txt
du -sh /www/wwwroot/mirror.repohub.top/MacWave/* /srv/mirror/MacWave/* 2>/dev/null

# 1) 看清每个 location 到底指向哪棵树（决定哪些目录能删）
nginx -T 2>/dev/null | grep -A2 'location .*MacWave' | grep -E 'location|alias'
```

**真正被服务的那棵树**要留下；其余都可以挪走。典型的两类废数据：

```bash
QUAR=/root/trash-macwave-$STAMP
mkdir -p "$QUAR"

# A. /www 下只留 bottle 与 deps —— 代码树现在只写 /srv
for d in infosource core selfupdate python MacWave; do
    [ -d "/www/wwwroot/mirror.repohub.top/MacWave/$d" ] || continue
    mv "/www/wwwroot/mirror.repohub.top/MacWave/$d" "$QUAR/www-$d"
done

# B. /srv 下按仓库名建的大写目录（客户端用的是小写 selfupdate/python）
for d in Selfupdate Python; do
    [ -d "/srv/mirror/MacWave/$d" ] || continue
    mv "/srv/mirror/MacWave/$d" "$QUAR/srv-$d"
done
```

挪完再验一遍。三个前提，缺一个结论就会反过来：

1. **必须 `https://`**（或带 `Host` 头）：`http://127.0.0.1` 只给 301；
2. **必须带凭据**：`selfupdate`、`python`、`core`、`bottle`、`deps` 这些路径都开了
   HTTP 基本认证，**认证在碰文件系统之前发生** —— 不带 `-u` 时永远是 `401`，
   哪怕目录被删光了也还是 `401`，等于什么都没验；只有 `infosource` 是公开的；
3. 口令从密码文件读进变量，**不要 `echo`**：

```bash
MP=$(awk '$1=="REPOHUBUSER1"{print $2; exit}' /root/macwave-passwords.txt)
for u in \
  /MacWave/infosource/HEAD/pkg/pkginfo_arm64/versions \
  /MacWave/selfupdate/macwavedata/latest.toml \
  /MacWave/python/pythondata/latest.toml \
  /MacWave/core/4.4/lib/wave.py \
  /MacWave/core/4.0/lib/wave.py \
  /MacWave/bottle/jq/jq%401.8.2.arm64 ; do
    printf '%s  %s\n' \
      "$(curl -s -o /dev/null -w '%{http_code}' -u "REPOHUBUSER1:$MP" "https://mirror.repohub.top$u")" "$u"
done
unset MP
```

全是 `200` 就说明废数据确实没人读；一周后 `rm -rf "$QUAR"`。
有一条变成 `404`，就把它 `mv` 回去，并去 `nginx -T` 里找那条指错方向的 `alias`。

## 让服务器自己盯着（日常巡检）

镜像站是外部依赖：它坏了不会有任何人主动告诉你。用户那边只会看到「下载失败」，
多半也不会来反馈 —— 等你发现时可能已经坏了一周。

所以装一个每天跑一次的体检。三个文件，都放服务器 `/root/mirror-check/`，
源文件在仓库 [scripts/mirror-check/](../scripts/mirror-check/)：

| 文件 | 作用 |
| --- | --- |
| `check.sh` | 体检本体，只读。退出码 = 失败项数，0 表示全绿 |
| `run.sh` | cron 包装：跑 `check.sh` → 记一行到 `history.log`（留 120 行）→ 失败建 `ALERT`、通过删 `ALERT` |
| `install.sh` | 落地：`chmod +x`、写 cron 行、立刻试跑一次 |

```bash
# Mac 上（ControlPath 指向已有的 ssh 连接，一轮只输一次密码）
rsync -a -e "ssh -o ControlPath=$HOME/.ssh/cm-lw" \
  scripts/mirror-check/ root@<服务器>:/root/mirror-check/

# 服务器上
/bin/bash /root/mirror-check/install.sh
```

装完 cron 里多一行，每天 04:17 跑。**时间刻意不取整点**，避开全网都在打 GitHub 的时刻。

### 它查什么

| 段 | 内容 | 为什么必须查 |
| --- | --- | --- |
| 0 | 三棵树各自的文件数下限（886 / 69 / 30） | 目录被清空时，「有文件」类断言会**全部真空真** |
| 1 | 六个公开页与图片 200 | 页面 401 或 404 都意味着首页打不开 |
| 2 | 数据目录无凭据 401 | 公开可下 = 镜像被白嫖 |
| 3–4 | 两边账号交叉访问（各自 200、对方 401） | 隔离失效时最容易出的事故 |
| 5 | 两边 `realm` 必须不同 | realm 相同会导致浏览器把一方的凭据发给另一方 |
| 6 | 8 种路径归一化绕过（大小写、`//`、`./`、`%57`、`%2F`…） | 写错一条就是免费下载 |
| 7 | 三个真实产物的 `content-length` 与磁盘一致 | 挡「200 但内容是 404 页」这种空壳 |

### 怎么读结果

```bash
tail -5  /root/mirror-check/history.log   # 最近几次的结论
cat      /root/mirror-check/last-run.log  # 本次完整输出
ls       /root/mirror-check/ALERT         # 存在 = 当前有故障
```

`rc` 就是失败项数。**没有邮件通道** —— 服务器没装 MTA，`mail` 必然失败，所以报警只落在
`ALERT` 文件里。要真正「有人知道」，得靠外部监控盯这个文件，或者自己每天看一眼 `history.log`。

### 写这类脚本的五个坑（都踩过）

| 坑 | 后果 | 做法 |
| --- | --- | --- |
| `find … \| sort \| head -1` 配 `set -o pipefail` | `head` 读完一行就退出，`sort` 继续写吃 SIGPIPE，管道返回 141。**输出有值但函数返回非零** —— 大目录（886 个文件、路径约 62 KB，正好塞满管道）必失败，小目录（69 个）正常，极难查 | 先全量捕获再在 bash 里取首行：`all=$(… \| sort); all=${all%%$'\n'*}` |
| 挑靶子挑到点文件 | nginx 的 `location ~ /\.` 在认证**之前**返回 404，断言「应 401」必然假红 | 排除含点段的路径；客户端本来就不取这类文件 |
| 挑靶子挑到目录 | 目录请求返回 404 而不是 401，同样假红 | 只挑 `-type f` |
| 空目录静默通过 | 目录被清空时检查全绿 | 先断言数量下限 |
| 报完不销账 | 一次故障后 `ALERT` 永远存在，之后就没人看了 | 失败建、通过删，**双向** |

另外两条与 bash 3.2 有关，写任何服务器脚本都要注意：变量紧贴中文必须写 `${var}`（否则
locale 会把中文首字节吃进变量名）；`"${ARR[@]}"` 在空数组上会报 unbound，改用单一变量。

## 别被打穿：限速、防爆破，与校园网

镜像一旦对外，就要面对两件不同的事：**流量成本**与**误伤自己人**。这一节只讲这两件，
配置都落在宝塔的 nginx 上。

### 先看体量，判断该防什么

拿 Bottle 仓库实测（2026-11）：

| 指标 | 数值 |
| --- | --- |
| 资产数 | 217 个 |
| 总体积 | 2.2 GB |
| 平均 | 10.4 MB |
| 最大单文件 | `ollama@0.40.11.arm64.tgz` **172.9 MB** |
| 超 50 MB 的 | 6 个（全是 ollama），合计 0.9 GB = 全站 **40%** |

所以「被刷」的最坏画像是**有人循环拉 ollama**：一次 172.9 MB。月流量 1 TB 的话，
5800 次就打满。5 MB 的小包反而不值得防。

### 威胁模型：认证已经挡掉了大半

Bottle 全路径需要 HTTP 基本认证，所以：

| 威胁 | 能否发生 | 对策 |
| --- | --- | --- |
| 陌生人匿名刷 | ❌ 401 | 不用管 |
| 爆破口令 | ✅ 会一直试 | fail2ban |
| 凭据泄露 / 被共享 | ✅ **主要风险** | 换口令、按人发凭据、看流量曲线 |
| 一个用户开多线程拉大包 | ✅ | `limit_conn` + `limit_rate` |

### 关键：不要按 IP 限

**校园网是 NAT 出口**：几百个用户共用一个公网 IP。按 IP 限连接等于
「整个校区同时只能下 6 个文件」，正常用户会被自己的同学挤掉。

已经开了 `auth_basic` 的话，nginx 认证后会填 `$remote_user`。**同一个 NAT 后面，
每个用户的用户名不同** —— 按它限，就是每人一份独立配额：

| 限制对象 | 校园网 NAT 下 | 挡得住滥用吗 |
| --- | --- | --- |
| `limit_rate`（按**连接**） | ✅ 无影响 | 挡住单连接吃满带宽 |
| `limit_conn $remote_user` | ✅ 各算各的 | 挡住一个人开几十线程 |
| `limit_conn $binary_remote_addr` | ❌ 全校共用一个配额 | — |
| `limit_req $remote_user` | ✅ | 挡住脚本循环 |

### 配置

`limit_*_zone` 必须写在 `http { }` 里。宝塔的 http 段在
`/www/server/nginx/conf/nginx.conf`（面板：软件商店 → Nginx → 配置修改），
加三行：

```nginx
limit_conn_zone $remote_user zone=bottle_per_user:10m;
limit_req_zone  $remote_user zone=bottle_rate:10m rate=60r/m;
```

然后在**站点**的 `server { }` 里（宝塔：网站 → 设置 → 配置文件）加：

```nginx
location /MacWave/bottle/ {
    limit_conn bottle_per_user 4;      # 每个用户名同时 4 个连接
    limit_req  zone=bottle_rate burst=20 nodelay;

    # 按连接限速，与 IP 无关 —— 校园网下这条最该留
    limit_rate 20m;

    sendfile on;
    tcp_nopush on;
}

# 大包单独再压一档：装一次就很少重装，慢一点没关系
location ~ /MacWave/bottle/ollama/ {
    limit_rate 2m;
}
```

缓存头在[第五步](#第五步nginx-缓存头)已经写过，不用重复。

**Bottle 不要加 `limit_req` 的紧阈值**：一次带依赖的安装本来就是连续几次请求，
卡太紧会伤到自己人。上面的 `60r/m` 只用来挡脚本循环。

### fail2ban：阈值必须放宽

默认模板的 `maxretry = 6` 在校园网下是灾难 —— 网关后面只要有一个人爆破，
**整栋楼都被封**：

```ini
# /etc/fail2ban/jail.d/nginx-auth.conf
[nginx-http-auth]
enabled  = true
maxretry = 20        # 放宽：NAT 后面人多，撞上同一桶
findtime = 300
bantime  = 600       # 封短一点：误封时等 10 分钟就能重试
```

认证成功不计入失败次数，所以正常用户不受影响。

### 宝塔的两个坑

- 面板里的**「限速」开关**是按 `$binary_remote_addr` 实现的，与上面的
  `$remote_user` 方案冲突，别同时开。
- 面板保存配置时会重写站点 `.conf`。要改就在面板的「配置文件」页改，
  直接编辑 `/www/server/panel/vhost/nginx/<站点>.conf` 有被覆盖的风险。

改完：

```bash
nginx -t && nginx -s reload
```

### 分级开放：哪些可以匿名

如果确实想让一部分内容不需要口令，按「体积 × 是否公开」分级：

```nginx
# 公开代码与小文件：匿名
location = /MacWave/core/lib/install.sh { auth_basic off; }

# 大二进制：继续要认证
location /MacWave/bottle/ { … }
```

注意一旦匿名，`limit_conn $remote_user` 就失效了（没有用户名，全部落进空字符串
同一个桶），只能退回按 IP —— 而校园网下按 IP 会误伤。这就是为什么**建议只放开
`install.sh` 这类几十 KB 的文件**，Bottle 保持认证。

`install.sh` 还有一个零成本的去处：放 CDN，源站完全不承载它。

```bash
# 实测可达（本机到 github 不通时也能取到）
/bin/bash -c "$(curl -fsSL https://fastly.jsdelivr.net/gh/MacWaveOrg/MacWave@v4.2.3/lib/install.sh)"
```

用 **tag**（`@v4.2.3`）而不是分支（`@4.2`）：tag 不可变，不会被悄悄换内容；
jsDelivr 对分支引用有缓存，改了代码会有一段时间读到旧的。

### 最后一道：看流量曲线

口令泄露不会自己暴露，只有流量会：

```bash
# 按月看各路径实际发出去多少
grep "/MacWave/bottle/" /www/wwwlogs/<站点>.log \
  | awk '{sum += $10} END {printf "%.1f GB\n", sum/1024/1024/1024}'
```

超过预算就报警（宝塔的任务计划里写个 cron 即可）。这比任何限速都更能发现异常 ——
限速只能让单个人慢下来，发现不了「有 200 个人在用同一个口令」。

## 常见问题

**404，但文件确实在。** 按顺序查这三条：

1. 目录是不是多套了一层（`MacWave/MacWave/bottle`）：
   `ls /www/wwwroot/mirror.repohub.top/MacWave/` 应当直接列出 `bottle`、`deps`；
2. 环境变量是不是漏了 `MacWave`：
   要写 `https://mirror.repohub.top/MacWave/bottle`，不是 `https://mirror.repohub.top/bottle`；
3. 环境变量是不是又漏了 `bottle` / `deps` 后缀（客户端只往后再接 `/<包名>/<文件名>`）。

**`@` 到底要不要编码。** 两种形式 nginx 都接受：`jq%401.7.1.arm64` 与 `jq@1.7.1.arm64` 指向同一个文件。客户端拼地址时会编码（与 GitHub 给出的规范地址一致）。

**下载是 200 但内容是 404 页面。** 宝塔的「伪静态」或默认站点配置接管了请求。镜像站不需要任何 rewrite 规则，把伪静态设为「无」。

**速度慢。** 先确认带宽档位（5 Mbps 与 30 Mbps 差 6 倍）；再看是不是撞上月流量包上限被限速了。

**服务器要同步很久。** 首次全量 1.5 GB。`sync_payloads.py` 可以重复运行，中断后再跑会从已完成的继续（同名同校验值的直接跳过）。
